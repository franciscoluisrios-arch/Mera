
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/Button';
import * as dataService from '../services/dataService';
import { exportToJSON, getTimestampFilename } from '../utils/formatters';

const Home: React.FC = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
  };

  const handleBackupData = () => {
    const allData = dataService.getAllData();
    const filename = `gerenciador_financeiro_backup_${getTimestampFilename()}.json`;
    exportToJSON(allData, filename);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-8rem)] text-gray-800 p-4">
      <h1 className="text-4xl md:text-5xl font-extrabold text-blue-700 mb-6 text-center">
        Bem-vindo ao Gerenciador Financeiro!
      </h1>
      <p className="text-lg md:text-xl text-center max-w-2xl mb-8 leading-relaxed">
        Sua ferramenta definitiva para organizar suas finanças empresariais.
        Gerencie produtos, registre entradas e vendas, e acompanhe seu balancete de forma simples e eficaz.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-md">
        <Button onClick={() => handleNavigate('/cadastro-produtos')} size="lg" className="w-full">
          Cadastro de Produtos
        </Button>
        <Button onClick={() => handleNavigate('/entradas-investimentos')} size="lg" className="w-full">
          Entradas e Investimentos
        </Button>
        <Button onClick={() => handleNavigate('/vendas')} size="lg" className="w-full">
          Registrar Vendas
        </Button>
        <Button onClick={() => handleNavigate('/balancete')} size="lg" variant="secondary" className="w-full">
          Ver Balancete
        </Button>
      </div>

      <div className="mt-8 flex justify-center w-full max-w-md">
        <Button onClick={handleBackupData} variant="outline" className="w-full">
          Fazer Backup dos Dados (JSON)
        </Button>
      </div>

      <div className="mt-12 text-center text-gray-600">
        <p className="text-md italic">
          "A organização financeira é o primeiro passo para o sucesso."
        </p>
      </div>
    </div>
  );
};

export default Home;
