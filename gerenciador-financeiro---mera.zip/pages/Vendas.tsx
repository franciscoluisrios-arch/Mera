
import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { ProductSale, ExportColumn } from '../types';
import Input from '../components/Input';
import Button from '../components/Button';
import Table, { TableColumn } from '../components/Table';
import { formatCurrency, formatDate, exportToCSV, getTimestampFilename } from '../utils/formatters';
import Modal from '../components/Modal';

const Vendas: React.FC = () => {
  const {
    products,
    productSales,
    addSale,
    updateSale,
    deleteSale, // Added deleteSale
    loading,
    calculateCMV,
    calculateGrossMargin,
    calculateCurrentStock,
  } = useData();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSale, setEditingSale] = useState<ProductSale | null>(null);
  const [saleToDelete, setSaleToDelete] = useState<ProductSale | null>(null); // New state for delete
  const [isSaleDeleteModalOpen, setIsSaleDeleteModalOpen] = useState(false); // New state for delete modal
  const [saleDate, setSaleDate] = useState('');
  const [selectedProductId, setSelectedProductId] = useState('');
  const [quantity, setQuantity] = useState<string>('');
  const [unitPrice, setUnitPrice] = useState<string>('');
  const [formErrors, setFormErrors] = useState<{
    date?: string;
    productId?: string;
    quantity?: string;
    unitPrice?: string;
  }>({});

  const today = new Date().toISOString().split('T')[0];

  useEffect(() => {
    setSaleDate(today);
    if (products.length > 0) {
      setSelectedProductId(products[0].id);
    }
  }, [products]);

  const validateForm = () => {
    const errors: typeof formErrors = {};
    if (!saleDate) errors.date = 'Data é obrigatória.';
    if (!selectedProductId) errors.productId = 'Produto é obrigatório.';

    const qty = parseFloat(quantity.replace(',', '.'));
    if (isNaN(qty) || qty <= 0) {
      errors.quantity = 'Quantidade deve ser um número positivo.';
    } else {
      const currentStock = calculateCurrentStock(selectedProductId);
      // For editing, consider the quantity of the current sale as 'available'
      const originalQuantity = editingSale?.productId === selectedProductId ? editingSale.quantity : 0;
      const effectiveStock = currentStock + originalQuantity;

      if (qty > effectiveStock) {
        errors.quantity = `Estoque insuficiente. Disponível: ${effectiveStock}`;
      }
    }

    const price = parseFloat(unitPrice.replace(',', '.'));
    if (isNaN(price) || price < 0) errors.unitPrice = 'Preço unitário deve ser um número não negativo.';

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const qty = parseFloat(quantity.replace(',', '.'));
    const price = parseFloat(unitPrice.replace(',', '.'));
    const totalSale = qty * price;

    if (editingSale) {
      await updateSale({ ...editingSale, date: saleDate, productId: selectedProductId, quantity: qty, unitPrice: price, totalSale: totalSale });
    } else {
      await addSale({ date: saleDate, productId: selectedProductId, quantity: qty, unitPrice: price, totalSale: totalSale });
    }
    resetForm();
  };

  const handleEditSale = (sale: ProductSale) => {
    setEditingSale(sale);
    setSaleDate(sale.date);
    setSelectedProductId(sale.productId);
    setQuantity(String(sale.quantity));
    setUnitPrice(sale.unitPrice.toFixed(2).replace('.', ','));
    setIsModalOpen(true);
  };

  const handleDeleteSale = (sale: ProductSale) => { // New handleDeleteSale function
    setSaleToDelete(sale);
    setIsSaleDeleteModalOpen(true);
  };

  const confirmDeleteSale = async () => { // New confirmDeleteSale function
    if (saleToDelete) {
      await deleteSale(saleToDelete.id);
      resetForm(); // Reset form also clears delete state
    }
  };

  const resetForm = () => {
    setEditingSale(null);
    setSaleToDelete(null); // Clear delete state
    setIsSaleDeleteModalOpen(false); // Close delete modal
    setSaleDate(today);
    setSelectedProductId(products.length > 0 ? products[0].id : '');
    setQuantity('');
    setUnitPrice('');
    setFormErrors({});
    setIsModalOpen(false);
  };

  const enrichedSales = productSales.map((sale) => {
    const cmv = calculateCMV(sale.productId, sale.quantity);
    const grossMargin = calculateGrossMargin(sale.totalSale, cmv);
    const productName = products.find((p) => p.id === sale.productId)?.name || 'Produto Desconhecido';
    return { ...sale, cmv, grossMargin, productName };
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()); // Sort by date descending

  const columns: TableColumn<typeof enrichedSales[0]>[] = [
    { header: 'Data', accessor: (row) => formatDate(row.date) },
    { header: 'ID Produto', accessor: 'productId' },
    { header: 'Produto', accessor: 'productName' },
    { header: 'Qtd', accessor: 'quantity', className: 'text-right' },
    { header: 'Preço Unit. (R$)', accessor: (row) => formatCurrency(row.unitPrice), className: 'text-right' },
    { header: 'Total Venda (R$)', accessor: (row) => formatCurrency(row.totalSale), className: 'text-right font-semibold' },
    { header: 'CMV (R$)', accessor: (row) => formatCurrency(row.cmv), className: 'text-right' },
    { header: 'Margem Bruta (R$)', accessor: (row) => formatCurrency(row.grossMargin), className: 'text-right font-semibold text-green-700' },
    {
      header: 'Ações',
      accessor: (row) => (
        <div className="flex gap-2 justify-center">
          <Button variant="secondary" size="sm" onClick={() => handleEditSale(row)}>
            Editar
          </Button>
          <Button variant="danger" size="sm" onClick={() => handleDeleteSale(row)}>
            Excluir
          </Button>
        </div>
      ),
      className: 'text-center',
    },
  ];

  // Define columns for CSV export
  const exportSalesColumns: ExportColumn<typeof enrichedSales[0]>[] = [
    { header: 'Data', accessor: 'date' },
    { header: 'ID Produto', accessor: 'productId' },
    { header: 'Nome Produto', accessor: 'productName' },
    { header: 'Quantidade', accessor: 'quantity' },
    { header: 'Preco Unitario', accessor: 'unitPrice', isCurrency: true },
    { header: 'Total Venda', accessor: 'totalSale', isCurrency: true },
    { header: 'CMV', accessor: 'cmv', isCurrency: true },
    { header: 'Margem Bruta', accessor: 'grossMargin', isCurrency: true },
  ];

  const handleExportCSV = () => {
    const filename = `vendas_${getTimestampFilename()}.csv`;
    exportToCSV(exportSalesColumns, enrichedSales, filename);
  };


  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Registro de Vendas</h1>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <Button onClick={() => setIsModalOpen(true)}>
          Registrar Nova Venda
        </Button>
        <Button variant="outline" onClick={handleExportCSV}>
          Exportar para CSV
        </Button>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={resetForm}
        title={editingSale ? 'Editar Venda' : 'Registrar Nova Venda'}
        footer={
          <>
            <Button variant="secondary" onClick={resetForm} className="mr-2">
              Cancelar
            </Button>
            <Button onClick={handleSubmit} loading={loading}>
              {editingSale ? 'Salvar Alterações' : 'Salvar Venda'}
            </Button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="p-4">
          <Input
            id="saleDate"
            label="Data"
            type="date"
            value={saleDate}
            onChange={(e) => setSaleDate(e.target.value)}
            required
            error={formErrors.date}
          />
          <div className="mb-4">
            <label htmlFor="selectedProductId" className="block text-sm font-medium text-gray-700 mb-1">
              Produto
            </label>
            <select
              id="selectedProductId"
              value={selectedProductId}
              onChange={(e) => setSelectedProductId(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              required
            >
              {products.length === 0 && <option value="">Carregando produtos...</option>}
              {products.map((product) => (
                <option key={product.id} value={product.id}>
                  {product.name} (Estoque: {calculateCurrentStock(product.id) + (editingSale?.productId === product.id ? editingSale.quantity : 0)})
                </option>
              ))}
            </select>
            {formErrors.productId && <p className="mt-1 text-sm text-red-600">{formErrors.productId}</p>}
          </div>
          <Input
            id="quantity"
            label="Quantidade"
            type="text"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value.replace(/[^0-9]/g, ''))}
            placeholder="Ex: 5"
            required
            error={formErrors.quantity}
          />
          <Input
            id="unitPrice"
            label="Preço Unitário (R$)"
            type="text"
            value={unitPrice}
            onChange={(e) => {
              const cleanedValue = e.target.value.replace(/[^0-9,.]/g, '').replace(/,/g, '.');
              setUnitPrice(cleanedValue);
            }}
            placeholder="Ex: 120,00"
            required
            error={formErrors.unitPrice}
          />
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={isSaleDeleteModalOpen}
        onClose={resetForm}
        title="Confirmar Exclusão de Venda"
        footer={
          <>
            <Button variant="secondary" onClick={resetForm} className="mr-2">
              Cancelar
            </Button>
            <Button variant="danger" onClick={confirmDeleteSale} loading={loading}>
              Excluir
            </Button>
          </>
        }
      >
        <p className="p-4 text-gray-700">
          Tem certeza de que deseja excluir a venda do produto "
          <span className="font-semibold">{saleToDelete?.productId ? products.find(p => p.id === saleToDelete.productId)?.name : 'N/A'}</span>" (ID: {saleToDelete?.id})?
          Esta ação não pode ser desfeita.
        </p>
      </Modal>

      <div className="bg-white shadow-lg rounded-lg p-6">
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">Histórico de Vendas</h2>
        {loading ? (
          <p className="text-center text-gray-600">Carregando vendas...</p>
        ) : (
          <Table<typeof enrichedSales[0]>
            data={enrichedSales}
            columns={columns}
            keyAccessor="id"
            emptyMessage="Nenhuma venda registrada."
            rowClassName="odd:bg-white even:bg-gray-50"
          />
        )}
      </div>
    </div>
  );
};

export default Vendas;
