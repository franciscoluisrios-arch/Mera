
import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { Product, ExportColumn } from '../types';
import Input from '../components/Input';
import Button from '../components/Button';
import Table, { TableColumn } from '../components/Table';
import { formatCurrency, exportToCSV, getTimestampFilename } from '../utils/formatters';
import Modal from '../components/Modal';

const CadastroProdutos: React.FC = () => {
  const { products, addProduct, updateProduct, deleteProduct, loading } = useData(); // Added deleteProduct
  const [productName, setProductName] = useState('');
  const [averageCost, setAverageCost] = useState<string>('');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null); // New state for delete
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false); // New state for delete modal
  const [formErrors, setFormErrors] = useState<{ name?: string; cost?: string }>({});

  const validateForm = () => {
    const errors: { name?: string; cost?: string } = {};
    if (!productName.trim()) {
      errors.name = 'Nome do produto é obrigatório.';
    }
    const costValue = parseFloat(averageCost.replace(',', '.'));
    if (isNaN(costValue) || costValue < 0) {
      errors.cost = 'Custo médio deve ser um número positivo.';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const costValue = parseFloat(averageCost.replace(',', '.'));

    if (editingProduct) {
      await updateProduct({ ...editingProduct, name: productName, averageCost: costValue });
    } else {
      await addProduct({ name: productName, averageCost: costValue });
    }
    resetForm();
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    setProductName(product.name);
    setAverageCost(product.averageCost.toFixed(2).replace('.', ','));
    setIsModalOpen(true);
  };

  const handleDelete = (product: Product) => { // New handleDelete function
    setProductToDelete(product);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = async () => { // New confirmDelete function
    if (productToDelete) {
      await deleteProduct(productToDelete.id);
      resetForm(); // Reset form also clears delete state
    }
  };

  const resetForm = () => {
    setProductName('');
    setAverageCost('');
    setEditingProduct(null);
    setProductToDelete(null); // Clear delete state
    setIsModalOpen(false);
    setIsDeleteModalOpen(false); // Close delete modal
    setFormErrors({});
  };

  const columns: TableColumn<Product>[] = [
    { header: 'ID', accessor: 'id', className: 'font-semibold text-gray-900' },
    { header: 'Produto', accessor: 'name' },
    {
      header: 'Custo Médio (R$)',
      accessor: (product) => formatCurrency(product.averageCost),
      className: 'text-right',
    },
    {
      header: 'Ações',
      accessor: (product) => (
        <div className="flex gap-2 justify-center">
          <Button variant="secondary" size="sm" onClick={() => handleEdit(product)}>
            Editar
          </Button>
          <Button variant="danger" size="sm" onClick={() => handleDelete(product)}>
            Excluir
          </Button>
        </div>
      ),
      className: 'text-center',
    },
  ];

  // Define columns for CSV export
  const exportProductColumns: ExportColumn<Product>[] = [
    { header: 'ID', accessor: 'id' },
    { header: 'Produto', accessor: 'name' },
    { header: 'Custo Medio', accessor: 'averageCost', isCurrency: true },
  ];

  const handleExportCSV = () => {
    const filename = `produtos_cadastro_${getTimestampFilename()}.csv`;
    exportToCSV(exportProductColumns, products, filename);
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Cadastro de Produtos</h1>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <Button onClick={() => setIsModalOpen(true)}>
          Adicionar Novo Produto
        </Button>
        <Button variant="outline" onClick={handleExportCSV}>
          Exportar para CSV
        </Button>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={resetForm}
        title={editingProduct ? 'Editar Produto' : 'Adicionar Novo Produto'}
        footer={
          <>
            <Button variant="secondary" onClick={resetForm} className="mr-2">
              Cancelar
            </Button>
            <Button onClick={handleSubmit} loading={loading}>
              {editingProduct ? 'Salvar Alterações' : 'Adicionar Produto'}
            </Button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="p-4">
          <Input
            id="productName"
            label="Nome do Produto"
            type="text"
            value={productName}
            onChange={(e) => setProductName(e.target.value)}
            required
            error={formErrors.name}
          />
          <Input
            id="averageCost"
            label="Custo Médio (R$)"
            type="text" // Use text to allow comma input
            value={averageCost}
            onChange={(e) => {
              // Allow only numbers and a single comma/dot
              const cleanedValue = e.target.value.replace(/[^0-9,.]/g, '').replace(/,/g, '.');
              setAverageCost(cleanedValue);
            }}
            placeholder="Ex: 50,00"
            required
            error={formErrors.cost}
          />
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={isDeleteModalOpen}
        onClose={resetForm}
        title="Confirmar Exclusão"
        footer={
          <>
            <Button variant="secondary" onClick={resetForm} className="mr-2">
              Cancelar
            </Button>
            <Button variant="danger" onClick={confirmDelete} loading={loading}>
              Excluir
            </Button>
          </>
        }
      >
        <p className="p-4 text-gray-700">
          Tem certeza de que deseja excluir o produto "
          <span className="font-semibold">{productToDelete?.name}</span>" (ID: {productToDelete?.id})?
          Esta ação não pode ser desfeita.
        </p>
      </Modal>

      <div className="bg-white shadow-lg rounded-lg p-6">
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">Lista de Produtos</h2>
        {loading ? (
          <p className="text-center text-gray-600">Carregando produtos...</p>
        ) : (
          <Table<Product>
            data={products}
            columns={columns}
            keyAccessor="id"
            emptyMessage="Nenhum produto cadastrado."
            rowClassName="odd:bg-white even:bg-gray-50"
          />
        )}
      </div>
    </div>
  );
};

export default CadastroProdutos;
