
import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { ProductEntry, CashFlowTransaction, SelectOption, ExportColumn } from '../types';
import Input from '../components/Input';
import Button from '../components/Button';
import Table, { TableColumn } from '../components/Table';
import { formatCurrency, formatDate, exportToCSV, getTimestampFilename } from '../utils/formatters';
import { CASH_FLOW_TRANSACTION_TYPES } from '../constants';
import Modal from '../components/Modal';

const EntradasInvestimentos: React.FC = () => {
  const {
    products,
    productEntries,
    cashFlowTransactions,
    addEntry,
    updateEntry,
    deleteEntry, // Added deleteEntry
    addCashFlowTransaction,
    updateCashFlowTransaction,
    deleteCashFlowTransaction, // Added deleteCashFlowTransaction
    loading
  } = useData();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formType, setFormType] = useState<'productEntry' | 'cashFlow'>('productEntry');

  // Product Entry Form State
  const [editingEntry, setEditingEntry] = useState<ProductEntry | null>(null);
  const [entryToDelete, setEntryToDelete] = useState<ProductEntry | null>(null); // New state for delete
  const [isEntryDeleteModalOpen, setIsEntryDeleteModalOpen] = useState(false); // New state for delete modal
  const [entryDate, setEntryDate] = useState('');
  const [entryProductId, setEntryProductId] = useState('');
  const [entryQuantity, setEntryQuantity] = useState<string>('');
  const [entryUnitValue, setEntryUnitValue] = useState<string>('');
  const [entryFormErrors, setEntryFormErrors] = useState<{ date?: string; productId?: string; quantity?: string; unitValue?: string }>({});

  // Cash Flow Transaction Form State
  const [editingCashFlow, setEditingCashFlow] = useState<CashFlowTransaction | null>(null);
  const [cashFlowToDelete, setCashFlowToDelete] = useState<CashFlowTransaction | null>(null); // New state for delete
  const [isCashFlowDeleteModalOpen, setIsCashFlowDeleteModalOpen] = useState(false); // New state for delete modal
  const [cfDate, setCfDate] = useState('');
  const [cfType, setCfType] = useState<CashFlowTransaction['type']>('Aporte Sócio');
  const [cfDescription, setCfDescription] = useState('');
  const [cfAmount, setCfAmount] = useState<string>('');
  const [cfFormErrors, setCfFormErrors] = useState<{ date?: string; type?: string; description?: string; amount?: string }>({});

  const today = new Date().toISOString().split('T')[0];

  useEffect(() => {
    setEntryDate(today);
    setCfDate(today);
    if (products.length > 0) {
      setEntryProductId(products[0].id);
    }
  }, [products]);

  const validateEntryForm = () => {
    const errors: typeof entryFormErrors = {};
    if (!entryDate) errors.date = 'Data é obrigatória.';
    if (!entryProductId) errors.productId = 'Produto é obrigatório.';
    const quantity = parseFloat(entryQuantity.replace(',', '.'));
    if (isNaN(quantity) || quantity <= 0) errors.quantity = 'Quantidade deve ser um número positivo.';
    const unitValue = parseFloat(entryUnitValue.replace(',', '.'));
    if (isNaN(unitValue) || unitValue < 0) errors.unitValue = 'Valor unitário deve ser um número não negativo.';
    setEntryFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const validateCashFlowForm = () => {
    const errors: typeof cfFormErrors = {};
    if (!cfDate) errors.date = 'Data é obrigatória.';
    if (!cfType) errors.type = 'Tipo é obrigatório.';
    if (!cfDescription.trim()) errors.description = 'Descrição é obrigatória.';
    const amount = parseFloat(cfAmount.replace(',', '.'));
    if (isNaN(amount) || amount <= 0) errors.amount = 'Valor deve ser um número positivo.';
    setCfFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleEntrySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateEntryForm()) return;

    const quantity = parseFloat(entryQuantity.replace(',', '.'));
    const unitValue = parseFloat(entryUnitValue.replace(',', '.'));
    const total = quantity * unitValue;

    if (editingEntry) {
      await updateEntry({ ...editingEntry, date: entryDate, productId: entryProductId, quantity, unitValue, total });
    } else {
      await addEntry({ date: entryDate, productId: entryProductId, quantity, unitValue });
    }
    resetForms();
  };

  const handleCashFlowSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateCashFlowForm()) return;

    const amount = parseFloat(cfAmount.replace(',', '.'));

    if (editingCashFlow) {
      await updateCashFlowTransaction({ ...editingCashFlow, date: cfDate, type: cfType, description: cfDescription, amount });
    } else {
      await addCashFlowTransaction({ date: cfDate, type: cfType, description: cfDescription, amount });
    }
    resetForms();
  };

  const handleEditEntry = (entry: ProductEntry) => {
    setEditingEntry(entry);
    setFormType('productEntry');
    setEntryDate(entry.date);
    setEntryProductId(entry.productId);
    setEntryQuantity(String(entry.quantity));
    setEntryUnitValue(entry.unitValue.toFixed(2).replace('.', ','));
    setIsModalOpen(true);
  };

  const handleDeleteEntry = (entry: ProductEntry) => { // New handleDeleteEntry function
    setEntryToDelete(entry);
    setIsEntryDeleteModalOpen(true);
  };

  const confirmDeleteEntry = async () => { // New confirmDeleteEntry function
    if (entryToDelete) {
      await deleteEntry(entryToDelete.id);
      resetForms(); // Reset forms also clears delete state
    }
  };

  const handleEditCashFlow = (transaction: CashFlowTransaction) => {
    setEditingCashFlow(transaction);
    setFormType('cashFlow');
    setCfDate(transaction.date);
    setCfType(transaction.type);
    setCfDescription(transaction.description);
    setCfAmount(transaction.amount.toFixed(2).replace('.', ','));
    setIsModalOpen(true);
  };

  const handleDeleteCashFlow = (transaction: CashFlowTransaction) => { // New handleDeleteCashFlow function
    setCashFlowToDelete(transaction);
    setIsCashFlowDeleteModalOpen(true);
  };

  const confirmDeleteCashFlow = async () => { // New confirmDeleteCashFlow function
    if (cashFlowToDelete) {
      await deleteCashFlowTransaction(cashFlowToDelete.id);
      resetForms(); // Reset forms also clears delete state
    }
  };

  const resetForms = () => {
    setEditingEntry(null);
    setEditingCashFlow(null);
    setEntryToDelete(null); // Clear delete state
    setCashFlowToDelete(null); // Clear delete state
    setIsEntryDeleteModalOpen(false); // Close delete modal
    setIsCashFlowDeleteModalOpen(false); // Close delete modal
    setEntryDate(today);
    setEntryProductId(products.length > 0 ? products[0].id : '');
    setEntryQuantity('');
    setEntryUnitValue('');
    setEntryFormErrors({});

    setCfDate(today);
    setCfType('Aporte Sócio');
    setCfDescription('');
    setCfAmount('');
    setCfFormErrors({});

    setIsModalOpen(false);
  };

  const entryColumns: TableColumn<ProductEntry>[] = [
    { header: 'Data', accessor: (row) => formatDate(row.date) },
    { header: 'ID Produto', accessor: 'productId' },
    { header: 'Produto', accessor: (row) => products.find(p => p.id === row.productId)?.name || 'N/A' },
    { header: 'Qtd', accessor: 'quantity', className: 'text-right' },
    { header: 'Valor Unit. (R$)', accessor: (row) => formatCurrency(row.unitValue), className: 'text-right' },
    { header: 'Total (R$)', accessor: (row) => formatCurrency(row.total), className: 'text-right font-semibold' },
    {
      header: 'Ações',
      accessor: (row) => (
        <div className="flex gap-2 justify-center">
          <Button variant="secondary" size="sm" onClick={() => handleEditEntry(row)}>
            Editar
          </Button>
          <Button variant="danger" size="sm" onClick={() => handleDeleteEntry(row)}>
            Excluir
          </Button>
        </div>
      ),
      className: 'text-center',
    },
  ];

  const cashFlowColumns: TableColumn<CashFlowTransaction>[] = [
    { header: 'Data', accessor: (row) => formatDate(row.date) },
    { header: 'Tipo', accessor: 'type' },
    { header: 'Descrição', accessor: 'description' },
    { header: 'Valor (R$)', accessor: (row) => formatCurrency(row.amount), className: 'text-right font-semibold' },
    {
      header: 'Ações',
      accessor: (row) => (
        <div className="flex gap-2 justify-center">
          <Button variant="secondary" size="sm" onClick={() => handleEditCashFlow(row)}>
            Editar
          </Button>
          <Button variant="danger" size="sm" onClick={() => handleDeleteCashFlow(row)}>
            Excluir
          </Button>
        </div>
      ),
      className: 'text-center',
    },
  ];

  // Define columns for CSV export - Product Entries
  const exportEntryColumns: ExportColumn<ProductEntry>[] = [
    { header: 'Data', accessor: 'date' },
    { header: 'ID Produto', accessor: 'productId' },
    { header: 'Produto', accessor: (row) => products.find(p => p.id === row.productId)?.name || 'N/A' },
    { header: 'Quantidade', accessor: 'quantity' },
    { header: 'Valor Unitario', accessor: 'unitValue', isCurrency: true },
    { header: 'Total', accessor: 'total', isCurrency: true },
  ];

  const handleExportEntryCSV = () => {
    const filename = `entradas_produtos_${getTimestampFilename()}.csv`;
    exportToCSV(exportEntryColumns, productEntries, filename);
  };

  // Define columns for CSV export - Cash Flow Transactions
  const exportCashFlowColumns: ExportColumn<CashFlowTransaction>[] = [
    { header: 'Data', accessor: 'date' },
    { header: 'Tipo', accessor: 'type' },
    { header: 'Descricao', accessor: 'description' },
    { header: 'Valor', accessor: 'amount', isCurrency: true },
  ];

  const handleExportCashFlowCSV = () => {
    const filename = `fluxo_caixa_${getTimestampFilename()}.csv`;
    exportToCSV(exportCashFlowColumns, cashFlowTransactions, filename);
  };


  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Entradas e Investimentos</h1>

      <Button onClick={() => setIsModalOpen(true)} className="mb-6">
        Registrar Nova Entrada/Investimento
      </Button>

      <Modal
        isOpen={isModalOpen}
        onClose={resetForms}
        title={editingEntry || editingCashFlow ? 'Editar Transação' : 'Registrar Transação'}
        footer={
          <>
            <Button variant="secondary" onClick={resetForms} className="mr-2">
              Cancelar
            </Button>
            <Button onClick={formType === 'productEntry' ? handleEntrySubmit : handleCashFlowSubmit} loading={loading}>
              {editingEntry || editingCashFlow ? 'Salvar Alterações' : 'Salvar'}
            </Button>
          </>
        }
      >
        <div className="mb-4">
          <label htmlFor="transactionTypeSelector" className="block text-sm font-medium text-gray-700 mb-1">
            Tipo de Registro:
          </label>
          <select
            id="transactionTypeSelector"
            value={formType}
            onChange={(e) => {
              setFormType(e.target.value as 'productEntry' | 'cashFlow');
              // Clear editing state if switching form type
              setEditingEntry(null);
              setEditingCashFlow(null);
            }}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
          >
            <option value="productEntry">Compra de Produtos (Entrada)</option>
            <option value="cashFlow">Aporte/Outros Investimentos/Despesas</option>
          </select>
        </div>

        {formType === 'productEntry' ? (
          <form onSubmit={handleEntrySubmit}>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Registrar Compra de Produtos</h3>
            <Input
              id="entryDate"
              label="Data"
              type="date"
              value={entryDate}
              onChange={(e) => setEntryDate(e.target.value)}
              required
              error={entryFormErrors.date}
            />
            <div className="mb-4">
              <label htmlFor="entryProductId" className="block text-sm font-medium text-gray-700 mb-1">
                Produto
              </label>
              <select
                id="entryProductId"
                value={entryProductId}
                onChange={(e) => setEntryProductId(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
              >
                {products.length === 0 && <option value="">Carregando produtos...</option>}
                {products.map((product) => (
                  <option key={product.id} value={product.id}>
                    {product.name} (ID: {product.id})
                  </option>
                ))}
              </select>
              {entryFormErrors.productId && <p className="mt-1 text-sm text-red-600">{entryFormErrors.productId}</p>}
            </div>
            <Input
              id="entryQuantity"
              label="Quantidade"
              type="text"
              value={entryQuantity}
              onChange={(e) => setEntryQuantity(e.target.value.replace(/[^0-9]/g, ''))}
              placeholder="Ex: 10"
              required
              error={entryFormErrors.quantity}
            />
            <Input
              id="entryUnitValue"
              label="Valor Unitário (R$)"
              type="text"
              value={entryUnitValue}
              onChange={(e) => {
                const cleanedValue = e.target.value.replace(/[^0-9,.]/g, '').replace(/,/g, '.');
                setEntryUnitValue(cleanedValue);
              }}
              placeholder="Ex: 45,50"
              required
              error={entryFormErrors.unitValue}
            />
          </form>
        ) : (
          <form onSubmit={handleCashFlowSubmit}>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Registrar Aporte/Outras Transações</h3>
            <Input
              id="cfDate"
              label="Data"
              type="date"
              value={cfDate}
              onChange={(e) => setCfDate(e.target.value)}
              required
              error={cfFormErrors.date}
            />
            <div className="mb-4">
              <label htmlFor="cfType" className="block text-sm font-medium text-gray-700 mb-1">
                Tipo
              </label>
              <select
                id="cfType"
                value={cfType}
                onChange={(e) => setCfType(e.target.value as CashFlowTransaction['type'])}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
              >
                {CASH_FLOW_TRANSACTION_TYPES.map((typeOption) => (
                  <option key={typeOption.value} value={typeOption.value}>
                    {typeOption.label}
                  </option>
                ))}
              </select>
              {cfFormErrors.type && <p className="mt-1 text-sm text-red-600">{cfFormErrors.type}</p>}
            </div>
            <Input
              id="cfDescription"
              label="Descrição"
              type="text"
              value={cfDescription}
              onChange={(e) => setCfDescription(e.target.value)}
              required
              error={cfFormErrors.description}
            />
            <Input
              id="cfAmount"
              label="Valor (R$)"
              type="text"
              value={cfAmount}
              onChange={(e) => {
                const cleanedValue = e.target.value.replace(/[^0-9,.]/g, '').replace(/,/g, '.');
                setCfAmount(cleanedValue);
              }}
              placeholder="Ex: 5000,00"
              required
              error={cfFormErrors.amount}
            />
          </form>
        )}
      </Modal>

      {/* Product Entry Delete Confirmation Modal */}
      <Modal
        isOpen={isEntryDeleteModalOpen}
        onClose={resetForms}
        title="Confirmar Exclusão de Entrada"
        footer={
          <>
            <Button variant="secondary" onClick={resetForms} className="mr-2">
              Cancelar
            </Button>
            <Button variant="danger" onClick={confirmDeleteEntry} loading={loading}>
              Excluir
            </Button>
          </>
        }
      >
        <p className="p-4 text-gray-700">
          Tem certeza de que deseja excluir a entrada de produto do dia "
          <span className="font-semibold">{entryToDelete?.date ? formatDate(entryToDelete.date) : ''}</span>" (ID: {entryToDelete?.id})?
          Esta ação não pode ser desfeita.
        </p>
      </Modal>

      {/* Cash Flow Transaction Delete Confirmation Modal */}
      <Modal
        isOpen={isCashFlowDeleteModalOpen}
        onClose={resetForms}
        title="Confirmar Exclusão de Transação"
        footer={
          <>
            <Button variant="secondary" onClick={resetForms} className="mr-2">
              Cancelar
            </Button>
            <Button variant="danger" onClick={confirmDeleteCashFlow} loading={loading}>
              Excluir
            </Button>
          </>
        }
      >
        <p className="p-4 text-gray-700">
          Tem certeza de que deseja excluir a transação de "
          <span className="font-semibold">{cashFlowToDelete?.description}</span>" (Tipo: {cashFlowToDelete?.type}, ID: {cashFlowToDelete?.id})?
          Esta ação não pode ser desfeita.
        </p>
      </Modal>

      <div className="bg-white shadow-lg rounded-lg p-6 mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-semibold text-gray-800">Entradas de Produtos (Compras)</h2>
          <Button variant="outline" size="sm" onClick={handleExportEntryCSV}>
            Exportar para CSV
          </Button>
        </div>
        {loading ? (
          <p className="text-center text-gray-600">Carregando entradas...</p>
        ) : (
          <Table<ProductEntry>
            data={productEntries}
            columns={entryColumns}
            keyAccessor="id"
            emptyMessage="Nenhuma entrada de produto registrada."
            rowClassName="odd:bg-white even:bg-gray-50"
          />
        )}
      </div>

      <div className="bg-white shadow-lg rounded-lg p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-semibold text-gray-800">Aportes e Outras Transações Financeiras</h2>
          <Button variant="outline" size="sm" onClick={handleExportCashFlowCSV}>
            Exportar para CSV
          </Button>
        </div>
        {loading ? (
          <p className="text-center text-gray-600">Carregando transações...</p>
        ) : (
          <Table<CashFlowTransaction>
            data={cashFlowTransactions}
            columns={cashFlowColumns}
            keyAccessor="id"
            emptyMessage="Nenhuma transação financeira registrada."
            rowClassName="odd:bg-white even:bg-gray-50"
          />
        )}
      </div>
    </div>
  );
};

export default EntradasInvestimentos;
