

import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { BalanceSheetRow, ExportColumn } from '../types'; // Import ExportColumn
import Table, { TableColumn } from '../components/Table';
import Button from '../components/Button'; // Import Button
import { formatCurrency, exportToCSV, getTimestampFilename } from '../utils/formatters'; // Import exportToCSV and getTimestampFilename
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

const Balancete: React.FC = () => {
  const { getBalanceSheetData, loading } = useData();
  const [balanceSheet, setBalanceSheet] = useState<BalanceSheetRow[]>([]);
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    if (!loading) {
      const data = getBalanceSheetData();
      setBalanceSheet(data);

      // Prepare data for the chart
      const faturamentoBruto = data.find(row => row.label === '(+) Faturamento Bruto');
      const lucroLiquido = data.find(row => row.label === '(=) LUCRO LÍQUIDO');

      // Recharts expects an array of objects, where each object represents a data point
      // Here we want to compare Jan, Feb, and Total for Faturamento Bruto and Lucro Líquido
      const chartPoints = [
        { name: 'Janeiro', 'Faturamento Bruto': faturamentoBruto?.january, 'Lucro Líquido': lucroLiquido?.january },
        { name: 'Fevereiro', 'Faturamento Bruto': faturamentoBruto?.february, 'Lucro Líquido': lucroLiquido?.february },
        { name: 'Total Ano', 'Faturamento Bruto': faturamentoBruto?.totalYear, 'Lucro Líquido': lucroLiquido?.totalYear },
      ];
      setChartData(chartPoints);
    }
  }, [loading, getBalanceSheetData]);

  const columns: TableColumn<BalanceSheetRow>[] = [
    {
      header: 'Indicador',
      accessor: 'label',
      // The className property now correctly accepts a function
      className: (item) => (item.isTotal ? 'font-bold text-gray-900' : 'text-gray-700'),
    },
    {
      header: 'Janeiro',
      accessor: (row) => formatCurrency(row.january),
      // The className property now correctly accepts a function
      className: (item) => (item.isTotal ? 'font-bold text-gray-900 text-right' : 'text-gray-700 text-right'),
    },
    {
      header: 'Fevereiro',
      accessor: (row) => formatCurrency(row.february),
      // The className property now correctly accepts a function
      className: (item) => (item.isTotal ? 'font-bold text-gray-900 text-right' : 'text-gray-700 text-right'),
    },
    {
      header: 'Total Ano',
      accessor: (row) => formatCurrency(row.totalYear),
      // The className property now correctly accepts a function
      className: (item) => (item.isTotal ? 'font-bold text-blue-700 text-lg text-right' : 'text-gray-700 text-right'),
    },
  ];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-300 rounded-md shadow-lg text-sm text-gray-800">
          <p className="font-bold text-gray-900 mb-1">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={`item-${index}`} style={{ color: entry.color }}>
              {entry.name}: {formatCurrency(entry.value)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  // Define columns for CSV export
  const exportBalanceSheetColumns: ExportColumn<BalanceSheetRow>[] = [
    { header: 'Indicador', accessor: 'label' },
    { header: 'Janeiro', accessor: 'january', isCurrency: true },
    { header: 'Fevereiro', accessor: 'february', isCurrency: true },
    { header: 'Total Ano', accessor: 'totalYear', isCurrency: true },
  ];

  const handleExportCSV = () => {
    const filename = `balancete_${getTimestampFilename()}.csv`;
    exportToCSV(exportBalanceSheetColumns, balanceSheet, filename);
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Balancete (Painel de Controle)</h1>

      <div className="bg-white shadow-lg rounded-lg p-6 mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-semibold text-gray-800">Relatório Financeiro</h2>
          <Button variant="outline" size="sm" onClick={handleExportCSV}>
            Exportar para CSV
          </Button>
        </div>
        {loading ? (
          <p className="text-center text-gray-600">Calculando balancete...</p>
        ) : (
          <Table<BalanceSheetRow>
            data={balanceSheet}
            columns={columns}
            keyAccessor="label"
            emptyMessage="Dados do balancete não disponíveis."
            rowClassName={(item) => (item.isTotal ? 'bg-blue-50' : 'odd:bg-white even:bg-gray-50')}
            headerClassName="bg-blue-100"
          />
        )}
      </div>

      <div className="bg-white shadow-lg rounded-lg p-6">
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">Faturamento Bruto e Lucro Líquido</h2>
        {loading || chartData.length === 0 ? (
          <p className="text-center text-gray-600">Carregando dados do gráfico...</p>
        ) : (
          <ResponsiveContainer width="100%" height={300}>
            <BarChart
              data={chartData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200" />
              <XAxis dataKey="name" className="text-sm text-gray-700" />
              <YAxis
                tickFormatter={(value) => formatCurrency(value)}
                className="text-sm text-gray-700"
              />
              <Tooltip cursor={{ fill: 'rgba(0,0,0,0.1)' }} content={<CustomTooltip />} />
              <Legend wrapperStyle={{ paddingTop: '10px' }} />
              <Bar dataKey="Faturamento Bruto" fill="#4299E1" /> {/* Tailwind blue-500 */}
              <Bar dataKey="Lucro Líquido" fill="#38A169" /> {/* Tailwind green-600 */}
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
};

export default Balancete;