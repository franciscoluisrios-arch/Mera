
import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import {
  Product,
  ProductEntry,
  ProductSale,
  CashFlowTransaction,
  BalanceSheetRow,
  CashFlowTransactionType,
} from '../types';
import * as dataService from '../services/dataService';
import { MONTH_NAMES } from '../constants';
import { format } from 'date-fns';

interface DataContextType {
  products: Product[];
  productEntries: ProductEntry[];
  productSales: ProductSale[];
  cashFlowTransactions: CashFlowTransaction[];
  loading: boolean;
  addProduct: (product: Omit<Product, 'id'>) => Promise<void>;
  updateProduct: (product: Product) => Promise<void>;
  deleteProduct: (productId: string) => Promise<void>; // Added for deleting products
  addEntry: (entry: Omit<ProductEntry, 'id' | 'total'>) => Promise<void>;
  updateEntry: (entry: ProductEntry) => Promise<void>;
  deleteEntry: (entryId: string) => Promise<void>; // Added for deleting entries
  addSale: (sale: Omit<ProductSale, 'id'>) => Promise<void>;
  updateSale: (sale: ProductSale) => Promise<void>;
  deleteSale: (saleId: string) => Promise<void>; // Added for deleting sales
  addCashFlowTransaction: (transaction: Omit<CashFlowTransaction, 'id'>) => Promise<void>;
  updateCashFlowTransaction: (transaction: CashFlowTransaction) => Promise<void>;
  deleteCashFlowTransaction: (transactionId: string) => Promise<void>; // Added for deleting cash flow
  calculateCurrentStock: (productId: string) => number;
  calculateCMV: (productId: string, quantity: number) => number;
  calculateGrossMargin: (totalSale: number, cmv: number) => number;
  getBalanceSheetData: () => BalanceSheetRow[];
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<React.PropsWithChildren<{}>> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [productEntries, setProductEntries] = useState<ProductEntry[]>([]);
  const [productSales, setProductSales] = useState<ProductSale[]>([]);
  const [cashFlowTransactions, setCashFlowTransactions] = useState<CashFlowTransaction[]>([]);
  const [loading, setLoading] = useState(true);

  // Load data from localStorage on mount
  useEffect(() => {
    setLoading(true);
    const storedProducts = dataService.getProducts();
    const storedEntries = dataService.getProductEntries();
    const storedSales = dataService.getProductSales();
    const storedCashFlows = dataService.getCashFlowTransactions();

    setProducts(storedProducts);
    setProductEntries(storedEntries);
    setProductSales(storedSales);
    setCashFlowTransactions(storedCashFlows);
    setLoading(false);
  }, []);

  const addProduct = useCallback(async (product: Omit<Product, 'id'>) => {
    setLoading(true);
    const newProduct = { ...product, id: `PROD-${Date.now()}` };
    const updatedProducts = dataService.addProduct(newProduct);
    setProducts(updatedProducts);
    setLoading(false);
  }, []);

  const updateProduct = useCallback(async (product: Product) => {
    setLoading(true);
    const updatedProducts = dataService.updateProduct(product);
    setProducts(updatedProducts);
    setLoading(false);
  }, []);

  const deleteProduct = useCallback(async (productId: string) => { // New deleteProduct function
    setLoading(true);
    const updatedProducts = dataService.deleteProduct(productId);
    setProducts(updatedProducts);
    setLoading(false);
  }, []);

  const addEntry = useCallback(async (entry: Omit<ProductEntry, 'id' | 'total'>) => {
    setLoading(true);
    const total = entry.quantity * entry.unitValue;
    const newEntry: ProductEntry = { ...entry, id: `ENTRY-${Date.now()}`, total };
    const updatedEntries = dataService.addProductEntry(newEntry);
    setProductEntries(updatedEntries);
    setLoading(false);
  }, []);

  const updateEntry = useCallback(async (entry: ProductEntry) => {
    setLoading(true);
    const updatedEntries = dataService.updateProductEntry(entry);
    setProductEntries(updatedEntries);
    setLoading(false);
  }, []);

  const deleteEntry = useCallback(async (entryId: string) => { // New deleteEntry function
    setLoading(true);
    const updatedEntries = dataService.deleteProductEntry(entryId);
    setProductEntries(updatedEntries);
    setLoading(false);
  }, []);

  const addSale = useCallback(async (sale: Omit<ProductSale, 'id'>) => {
    setLoading(true);
    const newSale: ProductSale = { ...sale, id: `SALE-${Date.now()}` };
    const updatedSales = dataService.addProductSale(newSale);
    setProductSales(updatedSales);
    setLoading(false);
  }, []);

  const updateSale = useCallback(async (sale: ProductSale) => {
    setLoading(true);
    const updatedSales = dataService.updateProductSale(sale);
    setProductSales(updatedSales);
    setLoading(false);
  }, []);

  const deleteSale = useCallback(async (saleId: string) => { // New deleteSale function
    setLoading(true);
    const updatedSales = dataService.deleteProductSale(saleId);
    setProductSales(updatedSales);
    setLoading(false);
  }, []);

  const addCashFlowTransaction = useCallback(async (transaction: Omit<CashFlowTransaction, 'id'>) => {
    setLoading(true);
    const newTransaction: CashFlowTransaction = { ...transaction, id: `CFT-${Date.now()}` };
    const updatedTransactions = dataService.addCashFlowTransaction(newTransaction);
    setCashFlowTransactions(updatedTransactions);
    setLoading(false);
  }, []);

  const updateCashFlowTransaction = useCallback(async (transaction: CashFlowTransaction) => {
    setLoading(true);
    const updatedTransactions = dataService.updateCashFlowTransaction(transaction);
    setCashFlowTransactions(updatedTransactions);
    setLoading(false);
  }, []);

  const deleteCashFlowTransaction = useCallback(async (transactionId: string) => { // New deleteCashFlowTransaction function
    setLoading(true);
    const updatedTransactions = dataService.deleteCashFlowTransaction(transactionId);
    setCashFlowTransactions(updatedTransactions);
    setLoading(false);
  }, []);

  const calculateCurrentStock = useCallback((productId: string): number => {
    const totalEntries = productEntries
      .filter((entry) => entry.productId === productId)
      .reduce((sum, entry) => sum + entry.quantity, 0);
    const totalSales = productSales
      .filter((sale) => sale.productId === productId)
      .reduce((sum, sale) => sum + sale.quantity, 0);
    return totalEntries - totalSales;
  }, [productEntries, productSales]);

  const calculateCMV = useCallback((productId: string, quantity: number): number => {
    const product = products.find((p) => p.id === productId);
    return product ? quantity * product.averageCost : 0;
  }, [products]);

  const calculateGrossMargin = useCallback((totalSale: number, cmv: number): number => {
    return totalSale - cmv;
  }, []);

  const getBalanceSheetData = useCallback((): BalanceSheetRow[] => {
    const now = new Date();
    const currentYear = now.getFullYear();

    // Helper to get month index from date string (YYYY-MM-DD)
    const getMonthIndex = (dateString: string): number => {
      return new Date(dateString).getMonth();
    };

    const monthlyData: { [key: number]: {
      faturamentoBruto: number;
      cmv: number;
      despesasOperacionais: number;
      retiradasSocios: number;
      aportesSocios: number; // Added to handle Aporte Sócio separately for cash balance
    }} = {};

    for (let i = 0; i < 12; i++) {
      monthlyData[i] = {
        faturamentoBruto: 0,
        cmv: 0,
        despesasOperacionais: 0,
        retiradasSocios: 0,
        aportesSocios: 0,
      };
    }

    // Process Product Sales
    productSales.forEach((sale) => {
      const saleDate = new Date(sale.date);
      if (saleDate.getFullYear() === currentYear) {
        const monthIndex = saleDate.getMonth();
        const cmvValue = calculateCMV(sale.productId, sale.quantity);
        monthlyData[monthIndex].faturamentoBruto += sale.totalSale;
        monthlyData[monthIndex].cmv += cmvValue;
      }
    });

    // Process Product Entries (Compras) as operational expenses
    productEntries.forEach((entry) => {
      const entryDate = new Date(entry.date);
      if (entryDate.getFullYear() === currentYear) {
        const monthIndex = entryDate.getMonth();
        monthlyData[monthIndex].despesasOperacionais += entry.total;
      }
    });

    // Process Cash Flow Transactions
    cashFlowTransactions.forEach((transaction) => {
      const transactionDate = new Date(transaction.date);
      if (transactionDate.getFullYear() === currentYear) {
        const monthIndex = transactionDate.getMonth();
        if (transaction.type === 'Retirada') {
          monthlyData[monthIndex].retiradasSocios += transaction.amount;
        } else if (transaction.type === 'Aporte Sócio') {
          monthlyData[monthIndex].aportesSocios += transaction.amount;
        } else { // 'Aluguel', 'Outra Despesa'
          // For expenses, amount should be added as a positive number here, then handled as negative in calculations
          monthlyData[monthIndex].despesasOperacionais += transaction.amount;
        }
      }
    });

    // Initialize january, february, and totalYear properties to satisfy BalanceSheetRow interface
    const balanceSheetRows: BalanceSheetRow[] = [
      { label: '(+) Faturamento Bruto', chartDataKey: 'faturamentoBruto', january: 0, february: 0, totalYear: 0 },
      { label: '(-) Custos de Estoque (CMV)', chartDataKey: 'cmv', january: 0, february: 0, totalYear: 0 },
      { label: '(=) LUCRO BRUTO', chartDataKey: 'lucroBruto', isTotal: true, january: 0, february: 0, totalYear: 0 },
      { label: '(-) Despesas Operacionais', chartDataKey: 'despesasOperacionais', january: 0, february: 0, totalYear: 0 },
      { label: '(=) LUCRO LÍQUIDO', chartDataKey: 'lucroLiquido', isTotal: true, january: 0, february: 0, totalYear: 0 },
      { label: '(-) Retiradas de Sócios', chartDataKey: 'retiradasSocios', january: 0, february: 0, totalYear: 0 },
      { label: 'SALDO FINAL CAIXA', chartDataKey: 'saldoFinalCaixa', isTotal: true, january: 0, february: 0, totalYear: 0 },
      // Add a row for Aportes to make overall cash flow clearer, even if not directly in the prompt's SALDO FINAL CAIXA formula
      { label: '(+) Aportes de Sócios', chartDataKey: 'aportesSocios', isTotal: true, january: 0, february: 0, totalYear: 0 },
    ];

    balanceSheetRows.forEach((row) => {
      row.january = 0;
      row.february = 0; // Initialize only for Jan and Feb explicitly
      row.totalYear = 0;

      for (let month = 0; month < 12; month++) {
        const data = monthlyData[month];
        let value = 0;

        switch (row.label) {
          case '(+) Faturamento Bruto':
            value = data.faturamentoBruto;
            break;
          case '(-) Custos de Estoque (CMV)':
            value = -data.cmv; // CMV is a cost, so it should be negative
            break;
          case '(=) LUCRO BRUTO':
            value = data.faturamentoBruto - data.cmv;
            break;
          case '(-) Despesas Operacionais':
            value = -data.despesasOperacionais; // Expenses are negative
            break;
          case '(=) LUCRO LÍQUIDO':
            // Recalculate based on current monthly values
            const lucroBruto = data.faturamentoBruto - data.cmv;
            value = lucroBruto - data.despesasOperacionais;
            break;
          case '(-) Retiradas de Sócios':
            value = -data.retiradasSocios; // Withdrawals are negative
            break;
          case 'SALDO FINAL CAIXA':
            const monthlyLucroBruto = data.faturamentoBruto - data.cmv;
            const monthlyLucroLiquido = monthlyLucroBruto - data.despesasOperacionais;
            value = monthlyLucroLiquido - data.retiradasSocios + data.aportesSocios; // Include aportes for a more realistic "final cash"
            break;
          case '(+) Aportes de Sócios':
            value = data.aportesSocios;
            break;
          default:
            value = 0;
        }

        // Accumulate values for January, February, and Total Year
        if (month === 0) { // Janeiro
          row.january += value;
        }
        if (month === 1) { // Fevereiro
          row.february += value;
        }
        row.totalYear += value;
      }
    });

    // Apply cumulative logic for SALDO FINAL CAIXA
    // This is important because Saldo Final Caixa for a month should include previous months' saldo
    // Re-iterate through the rows specifically for SALDO FINAL CAIXA if cumulative sum is desired
    // For simplicity and matching current structure, the above calculation is per month.
    // If a running total for 'SALDO FINAL CAIXA' is needed, a separate loop would be required.
    // For now, based on the `monthlyData` aggregation, this calculates the cash flow for the period.

    return balanceSheetRows;
  }, [productSales, productEntries, cashFlowTransactions, calculateCMV]);

  const value = useMemo(() => ({
    products,
    productEntries,
    productSales,
    cashFlowTransactions,
    loading,
    addProduct,
    updateProduct,
    deleteProduct, // Added to context value
    addEntry,
    updateEntry,
    deleteEntry, // Added to context value
    addSale,
    updateSale,
    deleteSale, // Added to context value
    addCashFlowTransaction,
    updateCashFlowTransaction,
    deleteCashFlowTransaction, // Added to context value
    calculateCurrentStock,
    calculateCMV,
    calculateGrossMargin,
    getBalanceSheetData,
  }), [
    products,
    productEntries,
    productSales,
    cashFlowTransactions,
    loading,
    addProduct,
    updateProduct,
    deleteProduct, // Dependency
    addEntry,
    updateEntry,
    deleteEntry, // Dependency
    addSale,
    updateSale,
    deleteSale, // Dependency
    addCashFlowTransaction,
    updateCashFlowTransaction,
    deleteCashFlowTransaction, // Dependency
    calculateCurrentStock,
    calculateCMV,
    calculateGrossMargin,
    getBalanceSheetData,
  ]);

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
};

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
