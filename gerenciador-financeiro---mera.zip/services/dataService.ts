
import { Product, ProductEntry, ProductSale, CashFlowTransaction, CashFlowTransactionType } from '../types';

const PRODUCTS_STORAGE_KEY = 'products';
const PRODUCT_ENTRIES_STORAGE_KEY = 'productEntries';
const PRODUCT_SALES_STORAGE_KEY = 'productSales';
const CASH_FLOW_TRANSACTIONS_STORAGE_KEY = 'cashFlowTransactions';

// Helper to get data from localStorage
const getStoredData = <T,>(key: string): T[] => {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
};

// Helper to save data to localStorage
const setStoredData = <T,>(key: string, data: T[]): void => {
  localStorage.setItem(key, JSON.stringify(data));
};

// Initialize with some dummy data if localStorage is empty
const initializeData = () => {
  if (getStoredData<Product>(PRODUCTS_STORAGE_KEY).length === 0) {
    const initialProducts: Product[] = [
      { id: '101', name: 'Produto A', averageCost: 50.00 },
      { id: '102', name: 'Produto B', averageCost: 30.00 },
      { id: '103', name: 'Serviço de Consultoria', averageCost: 0.00 }, // Example of a service with no cost
    ];
    setStoredData(PRODUCTS_STORAGE_KEY, initialProducts);
  }

  if (getStoredData<ProductEntry>(PRODUCT_ENTRIES_STORAGE_KEY).length === 0) {
    const initialProductEntries: ProductEntry[] = [
      { id: 'ENTRY-1', date: '2024-01-02', productId: '101', quantity: 50, unitValue: 48.00, total: 2400.00 },
      { id: 'ENTRY-2', date: '2024-01-15', productId: '102', quantity: 70, unitValue: 28.00, total: 1960.00 },
    ];
    setStoredData(PRODUCT_ENTRIES_STORAGE_KEY, initialProductEntries);
  }

  if (getStoredData<ProductSale>(PRODUCT_SALES_STORAGE_KEY).length === 0) {
    const initialProductSales: ProductSale[] = [
      { id: 'SALE-1', date: '2024-01-10', productId: '101', quantity: 10, unitPrice: 80.00, totalSale: 800.00 },
      { id: 'SALE-2', date: '2024-01-20', productId: '102', quantity: 5, unitPrice: 50.00, totalSale: 250.00 },
      { id: 'SALE-3', date: '2024-02-05', productId: '101', quantity: 15, unitPrice: 75.00, totalSale: 1125.00 },
    ];
    setStoredData(PRODUCT_SALES_STORAGE_KEY, initialProductSales);
  }

  if (getStoredData<CashFlowTransaction>(CASH_FLOW_TRANSACTIONS_STORAGE_KEY).length === 0) {
    const initialCashFlowTransactions: CashFlowTransaction[] = [
      { id: 'CFT-1', date: '2024-01-01', type: 'Aporte Sócio', description: 'Investimento Inicial', amount: 15000.00 },
      { id: 'CFT-2', date: '2024-01-10', type: 'Aluguel', description: 'Sala Comercial', amount: 1200.00 },
      { id: 'CFT-3', date: '2024-01-15', type: 'Retirada', description: 'Pró-labore Sócio A', amount: 2000.00 },
      { id: 'CFT-4', date: '2024-02-01', type: 'Aluguel', description: 'Sala Comercial', amount: 1200.00 },
      { id: 'CFT-5', date: '2024-02-15', type: 'Retirada', description: 'Pró-labore Sócio B', amount: 1500.00 },
      { id: 'CFT-6', date: '2024-02-20', type: 'Outra Despesa', description: 'Material de Escritório', amount: 300.00 },
    ];
    setStoredData(CASH_FLOW_TRANSACTIONS_STORAGE_KEY, initialCashFlowTransactions);
  }
};

initializeData();

// Product functions
export const getProducts = (): Product[] => getStoredData(PRODUCTS_STORAGE_KEY);

export const addProduct = (product: Product): Product[] => {
  const products = getProducts();
  products.push(product);
  setStoredData(PRODUCTS_STORAGE_KEY, products);
  return products;
};

export const updateProduct = (updatedProduct: Product): Product[] => {
  const products = getProducts();
  const index = products.findIndex(p => p.id === updatedProduct.id);
  if (index > -1) {
    products[index] = updatedProduct;
    setStoredData(PRODUCTS_STORAGE_KEY, products);
  }
  return products;
};

export const deleteProduct = (productId: string): Product[] => { // New delete function
  let products = getProducts();
  products = products.filter(p => p.id !== productId);
  setStoredData(PRODUCTS_STORAGE_KEY, products);
  return products;
};

// Product Entry functions
export const getProductEntries = (): ProductEntry[] => getStoredData(PRODUCT_ENTRIES_STORAGE_KEY);

export const addProductEntry = (entry: ProductEntry): ProductEntry[] => {
  const entries = getProductEntries();
  entries.push(entry);
  setStoredData(PRODUCT_ENTRIES_STORAGE_KEY, entries);
  return entries;
};

export const updateProductEntry = (updatedEntry: ProductEntry): ProductEntry[] => {
  const entries = getProductEntries();
  const index = entries.findIndex(e => e.id === updatedEntry.id);
  if (index > -1) {
    entries[index] = { ...updatedEntry, total: updatedEntry.quantity * updatedEntry.unitValue };
    setStoredData(PRODUCT_ENTRIES_STORAGE_KEY, entries);
  }
  return entries;
};

export const deleteProductEntry = (entryId: string): ProductEntry[] => { // New delete function
  let entries = getProductEntries();
  entries = entries.filter(e => e.id !== entryId);
  setStoredData(PRODUCT_ENTRIES_STORAGE_KEY, entries);
  return entries;
};

// Product Sale functions
export const getProductSales = (): ProductSale[] => getStoredData(PRODUCT_SALES_STORAGE_KEY);

export const addProductSale = (sale: ProductSale): ProductSale[] => {
  const sales = getProductSales();
  sales.push(sale);
  setStoredData(PRODUCT_SALES_STORAGE_KEY, sales);
  return sales;
};

export const updateProductSale = (updatedSale: ProductSale): ProductSale[] => {
  const sales = getProductSales();
  const index = sales.findIndex(s => s.id === updatedSale.id);
  if (index > -1) {
    sales[index] = { ...updatedSale, totalSale: updatedSale.quantity * updatedSale.unitPrice };
    setStoredData(PRODUCT_SALES_STORAGE_KEY, sales);
  }
  return sales;
};

export const deleteProductSale = (saleId: string): ProductSale[] => { // New delete function
  let sales = getProductSales();
  sales = sales.filter(s => s.id !== saleId);
  setStoredData(PRODUCT_SALES_STORAGE_KEY, sales);
  return sales;
};

// Cash Flow Transaction functions
export const getCashFlowTransactions = (): CashFlowTransaction[] => getStoredData(CASH_FLOW_TRANSACTIONS_STORAGE_KEY);

export const addCashFlowTransaction = (transaction: CashFlowTransaction): CashFlowTransaction[] => {
  const transactions = getCashFlowTransactions();
  transactions.push(transaction);
  setStoredData(CASH_FLOW_TRANSACTIONS_STORAGE_KEY, transactions);
  return transactions;
};

export const updateCashFlowTransaction = (updatedTransaction: CashFlowTransaction): CashFlowTransaction[] => {
  const transactions = getCashFlowTransactions();
  const index = transactions.findIndex(t => t.id === updatedTransaction.id);
  if (index > -1) {
    transactions[index] = updatedTransaction;
    setStoredData(CASH_FLOW_TRANSACTIONS_STORAGE_KEY, transactions);
  }
  return transactions;
};

export const deleteCashFlowTransaction = (transactionId: string): CashFlowTransaction[] => { // New delete function
  let transactions = getCashFlowTransactions();
  transactions = transactions.filter(t => t.id !== transactionId);
  setStoredData(CASH_FLOW_TRANSACTIONS_STORAGE_KEY, transactions);
  return transactions;
};

// Function to get all data for backup
export const getAllData = () => {
  return {
    products: getProducts(),
    productEntries: getProductEntries(),
    productSales: getProductSales(),
    cashFlowTransactions: getCashFlowTransactions(),
  };
};
