

import { ExportColumn } from '../types'; // Import ExportColumn interface

export const formatCurrency = (value: number | undefined): string => {
  if (value === undefined || isNaN(value)) {
    return 'R$ 0,00';
  }
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
};

export const formatDate = (dateString: string): string => {
  const date = new Date(dateString + 'T00:00:00'); // Add T00:00:00 to avoid timezone issues
  return date.toLocaleDateString('pt-BR');
};

export const generateId = (prefix: string = 'ITEM'): string => {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
};

// Helper for generating timestamp for filenames
export const getTimestampFilename = (): string => {
  const now = new Date();
  const year = now.getFullYear();
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const day = now.getDate().toString().padStart(2, '0');
  const hours = now.getHours().toString().padStart(2, '0');
  const minutes = now.getMinutes().toString().padStart(2, '0');
  const seconds = now.getSeconds().toString().padStart(2, '0');
  return `${year}${month}${day}${hours}${minutes}${seconds}`;
};

// Function to export data to JSON file
export const exportToJSON = (data: any, filename: string) => {
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url); // Clean up the URL object
};

// Function to export data to CSV file
export const exportToCSV = <T>(
  columns: ExportColumn<T>[],
  data: T[],
  filename: string
) => {
  if (!data || data.length === 0) {
    alert('Nenhum dado para exportar.'); // Using alert for simplicity, could be a toast
    return;
  }

  const csvRows: string[] = [];

  // Headers
  const headers = columns.map(col => col.header).join(';');
  csvRows.push(headers);

  // Data rows
  data.forEach(item => {
    const values = columns.map(col => {
      // Fix: Change cellValue to 'any' to handle diverse types from item[col.accessor]
      let cellValue: any; 
      if (typeof col.accessor === 'function') {
        cellValue = col.accessor(item);
      } else {
        cellValue = item[col.accessor];
      }

      if (cellValue === undefined || cellValue === null) {
        cellValue = '';
      } else if (col.isCurrency && typeof cellValue === 'number') {
        // For CSV, use comma as decimal separator, fixed to 2 decimal places
        cellValue = cellValue.toFixed(2).replace('.', ',');
      } else if (typeof cellValue === 'number') {
        // Replace dot with comma for other numbers
        cellValue = String(cellValue).replace('.', ',');
      } else if (typeof cellValue === 'boolean') { // Handle boolean explicitly
        cellValue = cellValue ? 'Verdadeiro' : 'Falso';
      } else if (cellValue instanceof Date) { // Handle Date objects
        cellValue = formatDate(cellValue.toISOString().split('T')[0]);
      } else if (typeof cellValue === 'object') { // Handle general objects (e.g., if an object is mistakenly put in)
        cellValue = JSON.stringify(cellValue);
      } else {
        // Ensure all other types are converted to string
        cellValue = String(cellValue);
      }

      // Escape double quotes by replacing them with two double quotes
      // Fix: Add type guard to ensure cellValue is a string before calling .replace
      if (typeof cellValue === 'string') { 
        cellValue = cellValue.replace(/"/g, '""');
      }
      return `"${cellValue}"`; // Enclose all values in quotes
    });
    csvRows.push(values.join(';'));
  });

  const csvString = csvRows.join('\n');
  const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(link.href); // Clean up the URL object
};