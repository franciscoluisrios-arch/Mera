

import React from 'react';

export interface TableColumn<T> {
  header: string;
  accessor: keyof T | ((item: T) => React.ReactNode);
  // Fix: Allow className to be a function that returns a string for dynamic styling
  className?: string | ((item: T) => string); 
  headerClassName?: string; // Tailwind CSS classes for the header cell
}

interface TableProps<T> {
  data: T[];
  columns: TableColumn<T>[];
  keyAccessor: keyof T | ((item: T) => string); // Unique key for each row
  className?: string; // Tailwind CSS classes for the table container
  tableClassName?: string; // Tailwind CSS classes for the <table> element
  headerClassName?: string; // Tailwind CSS classes for the <thead> element
  rowClassName?: string | ((item: T, index: number) => string); // Tailwind CSS classes for each row
  cellClassName?: string; // Tailwind CSS classes for each cell
  emptyMessage?: string;
}

const Table = <T,>({
  data,
  columns,
  keyAccessor,
  className = '',
  tableClassName = '',
  headerClassName = '',
  rowClassName = '',
  cellClassName = '',
  emptyMessage = 'Nenhum dado disponível',
}: TableProps<T>) => {
  const getKeyValue = (item: T): string => {
    if (typeof keyAccessor === 'function') {
      return keyAccessor(item);
    }
    return String(item[keyAccessor]);
  };

  const getCellContent = (item: T, accessor: keyof T | ((item: T) => React.ReactNode)): React.ReactNode => {
    if (typeof accessor === 'function') {
      return accessor(item);
    }
    return String(item[accessor]);
  };

  return (
    <div className={`overflow-x-auto shadow-md sm:rounded-lg ${className}`}>
      <table className={`w-full text-sm text-left text-gray-500 ${tableClassName}`}>
        <thead className={`text-xs text-gray-700 uppercase bg-gray-50 ${headerClassName}`}>
          <tr>
            {columns.map((column, index) => (
              <th key={index} scope="col" className={`px-6 py-3 ${column.headerClassName || ''}`}>
                {column.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="px-6 py-4 text-center text-gray-500">
                {emptyMessage}
              </td>
            </tr>
          ) : (
            data.map((item, rowIndex) => (
              <tr
                key={getKeyValue(item)}
                className={`bg-white border-b hover:bg-gray-50 ${
                  typeof rowClassName === 'function' ? rowClassName(item, rowIndex) : rowClassName
                }`}
              >
                {columns.map((column, colIndex) => (
                  <td
                    key={`${getKeyValue(item)}-${String(column.accessor)}`}
                    // Fix: Conditionally apply column.className if it's a function or string
                    className={`px-6 py-4 whitespace-nowrap ${cellClassName} ${
                      typeof column.className === 'function' ? column.className(item) : column.className || ''
                    }`}
                  >
                    {getCellContent(item, column.accessor)}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default Table;