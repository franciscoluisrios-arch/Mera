
import React from 'react';
import { NavLink } from 'react-router-dom';
import { NAV_ITEMS } from '../constants';

interface NavbarProps {
  onLinkClick?: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onLinkClick }) => {
  return (
    <nav className="flex flex-col flex-1 px-2 py-4">
      <div className="flex items-center justify-center p-4 text-white text-2xl font-bold border-b border-gray-700 mb-4">
        Finanças APP
      </div>
      {NAV_ITEMS.map((item) => (
        <NavLink
          key={item.name}
          to={item.path}
          onClick={onLinkClick}
          className={({ isActive }) =>
            `flex items-center px-4 py-2 mt-2 text-gray-300 hover:bg-gray-700 hover:text-white rounded-md transition-colors duration-200 ease-in-out ${
              isActive ? 'bg-gray-900 text-white' : ''
            }`
          }
        >
          {item.name}
        </NavLink>
      ))}
    </nav>
  );
};

export default Navbar;
